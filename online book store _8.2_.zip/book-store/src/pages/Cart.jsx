function Cart({ cart }) {
  const total = cart.reduce((sum, book) => sum + book.price, 0);

  return (
    <main className="page">
      <h1>Shopping Cart 🛒</h1>

      {cart.length === 0 ? (
        <div className="status-card">
          <div className="big-icon">🛒</div>
          <h2>Your cart is empty</h2>
          <p>Add a book from the Book Details page.</p>
        </div>
      ) : (
        <div className="cart-list">
          {cart.map((book) => (
            <div className="cart-item" key={book.id}>
              <div>
                <h3>{book.title}</h3>
                <p>Book ID: {book.id} · {book.author}</p>
              </div>
              <strong>₹{book.price}</strong>
            </div>
          ))}
          <div className="cart-total">
            <span>Total</span>
            <strong>₹{total}</strong>
          </div>
        </div>
      )}
    </main>
  );
}

export default Cart;