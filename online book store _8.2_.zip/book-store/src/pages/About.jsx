function About() {
  return (
    <main className="page">
      <div className="content-card">
        <h1>About Online Book Store</h1>
        <p>
          This React application demonstrates client-side routing and lifecycle
          functionality for an Online Book Store.
        </p>

        <h3>Features</h3>
        <ul>
          <li>Navigation using React Router and NavLink</li>
          <li>Dynamic book details using useParams()</li>
          <li>Book loading using useEffect()</li>
          <li>Cleanup when the book ID changes</li>
          <li>Cart state using useState()</li>
          <li>404 page and invalid book handling</li>
        </ul>
      </div>
    </main>
  );
}

export default About;