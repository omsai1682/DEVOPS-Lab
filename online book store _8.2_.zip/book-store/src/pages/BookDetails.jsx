import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { books } from "../data/books";

function BookDetails({ addToCart }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    setBook(null);

    const timer = setTimeout(() => {
      const selectedBook = books.find((item) => item.id === Number(id));
      setBook(selectedBook || null);
      setLoading(false);
    }, 500);

    return () => {
      clearTimeout(timer);
      console.log(`Cleanup executed for book ID: ${id}`);
    };
  }, [id]);

  if (loading) {
    return (
      <main className="page">
        <div className="status-card">
          <div className="spinner"></div>
          <h2>Loading book details...</h2>
          <p>Loading information for book ID {id}</p>
        </div>
      </main>
    );
  }

  if (!book) {
    return (
      <main className="page">
        <div className="status-card">
          <div className="big-icon">🔎</div>
          <h2>Book Not Found</h2>
          <p>No book exists with ID {id}.</p>
          <button className="button" onClick={() => navigate("/books")}>
            Back to Books
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="page">
      <div className="details-card">
        <div className="book-icon large">📖</div>
        <div>
          <span className="badge">BOOK ID: {book.id}</span>
          <h1>{book.title}</h1>
          <h3>Author: {book.author}</h3>
          <div className="price large-price">₹{book.price}</div>
          <p>{book.description}</p>

          <div className="actions">
            <button className="button" onClick={() => addToCart(book)}>
              Add to Cart
            </button>
            <button className="button secondary" onClick={() => navigate(-1)}>
              Go Back
            </button>
          </div>
        </div>
      </div>

      <div className="lifecycle-note">
        <strong>Lifecycle demonstration:</strong> useEffect loads this book
        when the component mounts and runs again whenever the route ID changes.
        Its cleanup function clears the pending loading timer.
      </div>
    </main>
  );
}

export default BookDetails;