import { Link } from "react-router-dom";

function Home() {
  return (
    <main className="page hero">
      <div className="hero-card">
        <span className="badge">React Routing Assignment</span>
        <h1>Welcome to Online Book Store 📚</h1>
        <p>
          Browse books, view dynamic book details, add books to your cart,
          and navigate between pages without reloading the application.
        </p>
        <Link className="button" to="/books">Browse Books</Link>
      </div>
    </main>
  );
}

export default Home;