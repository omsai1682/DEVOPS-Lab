import { Link } from "react-router-dom";

function NotFound() {
  return (
    <main className="page">
      <div className="status-card">
        <div className="error-code">404</div>
        <h2>Page Not Found</h2>
        <p>The page you are looking for does not exist.</p>
        <Link className="button" to="/">Go Home</Link>
      </div>
    </main>
  );
}

export default NotFound;