import { Link } from "react-router-dom";
import { books } from "../data/books";

function Books() {
  return (
    <main className="page">
      <h1>Available Books</h1>
      <p className="subtitle">Choose a book to view its dynamic details.</p>

      <div className="book-grid">
        {books.map((book) => (
          <article className="book-card" key={book.id}>
            <div className="book-icon">📖</div>
            <div className="book-id">BOOK ID: {book.id}</div>
            <h2>{book.title}</h2>
            <p><strong>Author:</strong> {book.author}</p>
            <p className="price">₹{book.price}</p>
            <Link className="button" to={`/books/${book.id}`}>
              View Details
            </Link>
          </article>
        ))}
      </div>
    </main>
  );
}

export default Books;