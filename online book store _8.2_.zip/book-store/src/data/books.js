export const books = [
  {
    id: 101,
    title: "The Great Adventure",
    author: "John Smith",
    price: 499,
    description: "An exciting adventure book full of mystery, exploration and discovery."
  },
  {
    id: 102,
    title: "Learning React",
    author: "David Brown",
    price: 699,
    description: "A practical introduction to React components, routing, state and hooks."
  },
  {
    id: 103,
    title: "JavaScript Mastery",
    author: "Sarah Wilson",
    price: 599,
    description: "Learn modern JavaScript concepts and programming techniques."
  }
];