# Online Book Store - Assignment 8.2.2

React Routing and lifecycle functionality project based on the supplied Week 8 PDF.

## Requirements covered
- Home, Books, Book Details, Cart, About and NotFound pages
- React Router navigation without full page reload
- Dynamic `/books/:id` route
- `useParams()` for book ID
- `useState()` for cart state
- `useEffect()` for loading book details
- Loading message
- Effect re-runs when book ID changes
- Cleanup function
- Books 101, 102 and 103
- Go Back button
- Add to Cart button
- Cart count in navigation
- Invalid book ID -> Book Not Found
- 404 route

## Run
```bash
npm install
npm run dev
```

Open the localhost URL shown by Vite.

## Build check
```bash
npm run build
```
